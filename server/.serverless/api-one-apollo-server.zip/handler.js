module.exports=function(e){var t={};function o(n){if(t[n])return t[n].exports;var r=t[n]={i:n,l:!1,exports:{}};return e[n].call(r.exports,r,r.exports,o),r.l=!0,r.exports}return o.m=e,o.c=t,o.d=function(e,t,n){o.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:n})},o.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},o.t=function(e,t){if(1&t&&(e=o(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var n=Object.create(null);if(o.r(n),Object.defineProperty(n,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)o.d(n,r,function(t){return e[t]}.bind(null,r));return n},o.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return o.d(t,"a",t),t},o.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},o.p="",o(o.s=1)}([function(e,t){e.exports=require("apollo-server-lambda")},function(e,t,o){const{ApolloServer:n,gql:r}=o(0),{buildFederatedSchema:i}=o(2),d=new n({schema:i([{typeDefs:o(3),resolvers:o(4)}]),context:({event:e,context:t})=>({headers:e.headers,functionName:t.functionName,event:e,context:t})});t.graphql=d.createHandler({cors:{origin:"*",credentials:!0,methods:"GET, POST",allowedHeaders:"Origin, X-Requested-With, Content-Type, Accept, Authorization"}})},function(e,t){e.exports=require("@apollo/federation")},function(e,t,o){"use strict";o.r(t);const{gql:n}=o(0),r=n`
  type Todo {
    id: ID!
    userId: String!
    completed: Boolean!
    createdOn: String!
    description: String!
    lastEdited: String!
  }
  type Query {
    getTodos(userId: string!): [Todo]!
  }

  type Mutation {
    addTodo(input: Todo!): Todo
    editTodo(input: EditTodoInput!): Todo
    deleteTodo(input: String!): Todo
  }

  input EditTodoInput {
    userId: String!
    id:String!
    completed: Boolean
    description: String
    lastEdited: String
  }

`;t.default=r},function(e,t){}]);
//# sourceMappingURL=handler.js.map